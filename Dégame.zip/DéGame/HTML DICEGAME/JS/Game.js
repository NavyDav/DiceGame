// Variables pour les scores, le joueur actuel, le nombre de parties jouées et les victoires par joueur
var joueur1Score = 0;
var joueur2Score = 0;
var joueurAct = 1;
var scoreLimite = 50; // Limite de score pour gagner
var partiesJouees = 0;
var victoiresJoueur1 = 0;
var victoiresJoueur2 = 0;
const perdantCommence = true; // Le perdant commence le prochain tour

// Fonction appelée lorsque le bouton "Lancer le dé" est cliqué
function lancerDe() {
        // Génère une valeur aléatoire entre 1 et 6 pour le dé
        var valeurDe = Math.floor(Math.random() * 6) + 1;

        // Affiche la valeur du dé dans l'élément avec l'ID "de-init"
        document.getElementById("de-init").innerHTML = valeurDe;

    
        
       

        if (valeurDe === 1) {
                // Si la valeur du dé est 1, change de joueur en alternant entre les joueurs 1 et 2
                // Alternative à la formulation joueurAct = joueurAct === 1 ? 2 : 1;
                if (joueurAct === 1) {
                        joueurAct = 2;
                } else {
                        joueurAct = 1;
                }

                // Affiche un message indiquant le joueur actuel
                document.getElementById("result").innerHTML =
                        "C'est au tour du Joueur " + joueurAct + " !";
        } else {
                if (joueurAct === 1) {
                        // Si le joueur actuel est le joueur 1, ajoute la valeur du dé à son score
                        joueur1Score += valeurDe;

                        // Met à jour l'affichage du score du joueur 1
                        document.getElementById("joueur1-score").innerHTML =
                                "Joueur 1: " + joueur1Score + " points";
                } else {
                        // Si le joueur actuel est le joueur 2, ajoute la valeur du dé à son score
                        joueur2Score += valeurDe;

                        // Met à jour l'affichage du score du joueur 2
                        document.getElementById("joueur2-score").innerHTML =
                        "Joueur 2: " + joueur2Score + " points";
                }

                if (joueur1Score >= scoreLimite || joueur2Score >= scoreLimite) {
                        // Si le score d'un joueur atteint ou dépasse la limite de score, détermine le gagnant
                        var gagnant;
                        var perdant;

                        if (joueur1Score >= scoreLimite) {
                                gagnant = "Joueur 1";
                                perdant = "Joueur 2";
                                victoiresJoueur1++;
                        } else {
                                gagnant = "Joueur 2";
                                perdant = "Joueur 1";
                                victoiresJoueur2++;
                        }

                        // Incrémente le nombre de parties jouées
                        partiesJouees++;

                        // Affiche un message de victoire avec le score du gagnant et le nombre de parties jouées
                        document.getElementById("result").innerHTML =
                                gagnant +
                                " a gagné avec un total de " +
                                (joueur1Score >= scoreLimite ? joueur1Score : joueur2Score) +
                                " points! <br> Parties jouées : " +
                                partiesJouees;

                        // Efface la valeur du dé affichée
                        document.getElementById("de-init").innerHTML = "";
                        // Fonction appelée lorsque le bouton "Rejouer" est cliqué

                        
                }
        }
}


document.addEventListener("DOMContentLoaded", function() {
    var sonAcc = document.getElementById("gta");

    // Play the sound when the page loads
    document.getElementsById("gta").play();
});
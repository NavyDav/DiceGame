function rejouer() {
    // Réinitialise les scores, le joueur actuel, les affichages et le perdant commence
    joueur1Score = 0;
    joueur2Score = 0;
    joueurAct = 1;
    partiesJouees = 0;
    victoiresJoueur1 = 0;
    victoiresJoueur2 = 0;
    perdantCommence = true;

    document.getElementById("joueur1-score").innerHTML =
            "Joueur 1: 0 points";
    document.getElementById("joueur2-score").innerHTML =
            "Joueur 2: 0 points";
    document.getElementById("result").innerHTML = "";
    document.getElementById("victoires-joueur1").innerHTML =
            "Victoires Joueur 1: " + victoiresJoueur1;
    document.getElementById("victoires-joueur2").innerHTML =
            "Victoires Joueur 2: " + victoiresJoueur2;
    document.getElementById("de-init").innerHTML = "";
    document.getElementById("btn-lancer").disabled = false;
}
